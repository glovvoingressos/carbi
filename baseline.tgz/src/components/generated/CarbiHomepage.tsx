import { useState, type FormEvent } from 'react';
const heroPhoto = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/454278803158601728/454278803158601729/25276ea44dbe7267e43b9561479351236238243c7c24df6c2b5f26114d80e7b8.jpg";
const platePhoto = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/454278803158601728/454278803158601729/210f952c29636b4a0db4e5212155875aafaae9ecf59ebdd83be6d1adbcaf6aed.jpg";
const listingPhotos = ["https://ygrnbudqtfuadkpbgttw.supabase.co/storage/v1/object/public/vehicle-listings/80b3ad58-4219-455f-a386-3f80e63a5558/5343c399-2691-42d0-a427-b619972bdcdb/01-1790189656191-34350146-66f3-4f7e-80bb-62c4c2643bbc.jpg", "https://ygrnbudqtfuadkpbgttw.supabase.co/storage/v1/object/public/vehicle-listings/da195270-ee10-44b2-9e45-040e84d0ce5e/d9e42566-c211-4f46-bfd1-9e6079cff593/01-1790082775763-WhatsApp-Image-2026-09-17-at-19.21.42.jpeg", "https://ygrnbudqtfuadkpbgttw.supabase.co/storage/v1/object/public/vehicle-listings/da195270-ee10-44b2-9e45-040e84d0ce5e/079e3c7c-91e5-49d9-82db-154e366aa4c8/01-1790081141653-WhatsApp-Image-2026-07-23-at-15.56.59.jpeg"];
const Arrow = () => <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" className="cc-arrow">
    <path d="M5 12h14m-7-7 7 7-7 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>;
const SearchIcon = () => <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" className="cc-search-icon">
    <circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" strokeWidth="1.8" />
    <path d="m16 16 4.5 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>;
const CheckIcon = () => <svg aria-hidden="true" viewBox="0 0 20 20" fill="none" className="cc-check-icon">
    <path d="m4.5 10 3.4 3.4 7.6-7.2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M10 1.8 16.6 4v5.2c0 4.2-2.8 7.3-6.6 9-3.8-1.7-6.6-4.8-6.6-9V4L10 1.8Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
  </svg>;
const styles = `
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
.carbi-canvas, .carbi-canvas * { box-sizing: border-box; }
.carbi-canvas {
  --ink:#212121; --soft:#3a3a3a; --muted:#6f6f6f; --line:rgba(33,33,33,.09);
  --lime:#eafc5f; --forest:#1a2f1e; --paper:#fff; --surface:#f8f8f8;
  width:100%; min-height:100vh; overflow:hidden; background:var(--paper); color:var(--ink);
  font-family:'Poppins',Arial,sans-serif; -webkit-font-smoothing:antialiased;
}
.carbi-canvas button, .carbi-canvas input { font:inherit; }
.cc-wrap { width:min(1240px, calc(100% - 64px)); margin:0 auto; }
.cc-header { position:relative; z-index:2; background:rgba(255,255,255,.96); border-bottom:1px solid var(--line); }
.cc-nav { min-height:78px; display:flex; align-items:center; justify-content:space-between; gap:32px; }
.cc-logo { color:var(--ink); font-size:27px; font-weight:800; letter-spacing:-2px; line-height:1; text-decoration:none; }
.cc-logo span { color:inherit; }
.cc-links { display:flex; align-items:center; gap:clamp(20px,3vw,42px); }
.cc-links a, .cc-login { color:var(--soft); text-decoration:none; font-size:14px; font-weight:500; transition:color .18s ease; }
.cc-links a:hover, .cc-login:hover { color:#16855c; }
.cc-nav-actions { display:flex; align-items:center; gap:22px; }
.cc-post, .cc-button { min-height:48px; display:inline-flex; align-items:center; justify-content:center; gap:10px; border:0; border-radius:999px; padding:0 22px; background:var(--ink); color:white; font-weight:600; font-size:14px; text-decoration:none; cursor:pointer; transition:transform .18s ease, background .18s ease; }
.cc-button { white-space:nowrap; }
.cc-arrow { width:18px; height:18px; flex:0 0 auto; }
.cc-post { flex-shrink:0; white-space:nowrap; border-radius:8px; }
.cc-post .cc-arrow { width:16px; height:16px; flex:0 0 auto; }
.cc-post:hover, .cc-button:hover { background:#343434; transform:translateY(-2px); }
.cc-menu-toggle { display:none; width:44px; height:44px; align-items:center; justify-content:center; border:1px solid var(--line); border-radius:50%; background:#fff; color:var(--ink); cursor:pointer; }
.cc-menu-toggle svg { width:20px; height:20px; }
.cc-hero { padding:88px 0 70px; }
.cc-hero-grid { display:grid; grid-template-columns:minmax(0,1.12fr) minmax(360px,.88fr); align-items:center; gap:clamp(36px,5.7vw,74px); }
.cc-hero-copy { padding:10px 0; }
.cc-kicker { display:block; margin:0 0 18px; color:#16855c; font-size:11px; font-weight:700; letter-spacing:.18em; text-transform:uppercase; }
.cc-hero h1 { max-width:560px; margin:0; font-size:clamp(48px,5vw,62px); font-weight:700; letter-spacing:-.055em; line-height:1.16; }
.cc-hero h1 span { display:block; }
.cc-hero h1 u { text-decoration:none; box-shadow:inset 0 -.16em 0 var(--lime); }
.cc-lead { max-width:54ch; margin:24px 0 28px; color:var(--soft); font-size:16px; font-weight:300; line-height:1.75; }
.cc-hero-actions { display:flex; flex-wrap:wrap; gap:12px; }
.cc-button-lime { background:var(--lime); color:var(--ink); }
.cc-button-lime:hover { background:#dce94b; }
.cc-button-forest { background:#365c43; color:white; }
.cc-button-forest:hover { background:#294b35; }
.cc-button-quiet { border:1px solid var(--line); background:white; color:var(--ink); }
.cc-button-quiet:hover { background:var(--surface); }
.cc-proof { display:flex; align-items:center; gap:13px; margin-top:34px; color:var(--muted); font-size:12px; }
.cc-proof strong { color:var(--ink); font-weight:700; }
.cc-proof-dots { display:flex; padding-left:5px; }
.cc-proof-dots i { display:block; width:28px; height:28px; margin-left:-5px; border:2px solid white; border-radius:50%; background:#e4e9e4; }
.cc-proof-dots i:nth-child(2) { background:#202c35; }
.cc-proof-dots i:nth-child(3) { background:#d3c6a9; }
.cc-hero-visual { position:relative; min-width:0; }
.cc-hero-photo { display:block; width:100%; height:clamp(360px,34vw,435px); border-radius:30px; object-fit:cover; object-position:center; background:#e9e9e9; }
.cc-photo-caption { position:absolute; right:18px; bottom:18px; display:flex; align-items:center; gap:10px; max-width:calc(100% - 36px); padding:12px 16px; border:1px solid rgba(255,255,255,.65); border-radius:18px; background:rgba(255,255,255,.94); box-shadow:0 8px 24px rgba(0,0,0,.09); }
.cc-caption-icon { display:grid; width:34px; height:34px; flex:0 0 auto; place-items:center; border-radius:50%; background:var(--lime); }
.cc-caption-icon svg { width:17px; height:17px; }
.cc-photo-caption strong, .cc-photo-caption small { display:block; }
.cc-photo-caption strong { font-size:12px; font-weight:700; }
.cc-photo-caption small { margin-top:2px; color:var(--muted); font-size:10px; }
.cc-highlights { padding:20px 0 70px; }
.cc-highlight-grid { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); border-top:1px solid var(--line); border-bottom:1px solid var(--line); }
.cc-highlight { padding:24px 18px 24px 0; }
.cc-highlight + .cc-highlight { padding-left:24px; border-left:1px solid var(--line); }
.cc-highlight strong { display:block; font-size:30px; font-weight:700; letter-spacing:-.04em; }
.cc-highlight span { display:block; margin-top:4px; color:var(--muted); font-size:14px; font-weight:300; }
.cc-highlight strong span { display:inline; margin:0; color:#b57821; font-size:.7em; vertical-align:middle; }
.cc-plate { display:grid; grid-template-columns:minmax(0,1fr) minmax(360px,.96fr); gap:38px; align-items:stretch; padding:38px; border-radius:30px; background:linear-gradient(135deg,#233d2a,#1a2f1e 58%,#122017); color:white; }
.cc-plate-left { display:flex; flex-direction:column; justify-content:center; gap:24px; min-width:0; }
.cc-plate-photo { display:block; width:100%; height:100%; min-height:410px; border-radius:24px; object-fit:cover; object-position:center; }
.cc-plate-copy { display:flex; flex-direction:column; align-items:flex-start; justify-content:center; padding:12px 0; }
.cc-plate-copy .cc-kicker { margin-bottom:14px; color:var(--lime); }
.cc-plate h2 { max-width:13ch; margin:0; font-size:clamp(30px,3.8vw,48px); font-weight:700; letter-spacing:-.055em; line-height:1.06; }
.cc-plate-copy p { max-width:43ch; margin:17px 0 20px; color:rgba(255,255,255,.72); font-size:14px; font-weight:300; line-height:1.7; }
.cc-private { display:flex; align-items:center; gap:8px; color:rgba(255,255,255,.7); font-size:11px; }
.cc-private .cc-check-icon { color:var(--lime); }
.cc-search-card { align-self:center; padding:22px; border:1px solid rgba(255,255,255,.1); border-radius:22px; background:rgba(255,255,255,.09); }
.cc-search-card label { display:block; margin:0 0 10px; color:rgba(255,255,255,.8); font-size:12px; font-weight:600; }
.cc-input-row { display:flex; gap:10px; }
.cc-input-wrap { display:flex; min-width:0; flex:1; align-items:center; gap:10px; padding:0 15px; border-radius:999px; background:white; color:#16855c; }
.cc-input-wrap svg { width:18px; height:18px; flex:0 0 auto; }
.cc-input-wrap input { width:100%; min-width:0; height:52px; border:0; outline:0; background:transparent; color:var(--ink); font-size:16px; font-weight:700; letter-spacing:.13em; text-transform:uppercase; }
.cc-input-wrap input::placeholder { color:#8b928c; }
.cc-input-wrap:focus-within { outline:3px solid rgba(234,252,95,.65); }
.cc-search-submit { min-width:122px; border:0; border-radius:999px; background:var(--lime); color:var(--ink); font-size:13px; font-weight:700; cursor:pointer; transition:transform .18s ease, background .18s ease; }
.cc-search-submit:hover { background:#dce94b; transform:translateY(-1px); }
.cc-search-submit:disabled { opacity:.6; cursor:not-allowed; transform:none; }
.cc-form-note { min-height:18px; margin:10px 4px 0; color:#ffb8aa; font-size:11px; }
.cc-demo-result { margin-top:12px; padding:14px; border:1px solid rgba(234,252,95,.3); border-radius:14px; background:rgba(0,0,0,.15); }
.cc-demo-result small { display:block; color:var(--lime); font-size:10px; font-weight:600; letter-spacing:.04em; }
.cc-demo-result strong { display:block; margin-top:5px; font-size:15px; }
.cc-demo-result span { display:block; margin-top:3px; color:rgba(255,255,255,.7); font-size:11px; }
.cc-listings { padding:82px 0 94px; }
.cc-listing-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:18px; }
.cc-listing-card { overflow:hidden; border:1px solid var(--line); border-radius:20px; background:white; color:var(--ink); text-decoration:none; }
.cc-listing-card img { display:block; width:100%; height:220px; object-fit:cover; background:#f2f2f2; }
.cc-listing-copy { padding:18px; }
.cc-listing-copy small { display:block; color:var(--muted); font-size:11px; font-weight:600; letter-spacing:.08em; }
.cc-listing-copy h3 { margin:8px 0 12px; font-size:19px; line-height:1.2; }
.cc-listing-specs { display:flex; flex-wrap:wrap; gap:8px 14px; color:var(--muted); font-size:12px; }
.cc-listing-price { display:flex; align-items:baseline; justify-content:space-between; gap:8px; margin-top:18px; }
.cc-listing-price strong { font-size:20px; }
.cc-listing-price span { color:#16855c; font-size:11px; font-weight:600; }
.cc-showcase { padding:82px 0 94px; }
.cc-section-head { display:flex; align-items:flex-end; justify-content:space-between; gap:22px; margin-bottom:28px; }
.cc-section-head .cc-kicker { margin-bottom:10px; }
.cc-section-head h2 { margin:0; font-size:clamp(28px,3.5vw,40px); font-weight:700; letter-spacing:-.055em; line-height:1.08; }
.cc-text-link { display:inline-flex; align-items:center; gap:8px; color:var(--ink); font-size:13px; font-weight:600; text-decoration:none; white-space:nowrap; }
.cc-text-link .cc-arrow { width:18px; height:18px; }
.cc-solution-grid { display:grid; grid-template-columns:1.12fr .88fr; gap:16px; }
.cc-solution-main { position:relative; min-height:380px; overflow:hidden; border-radius:26px; background:var(--ink); color:white; }
.cc-solution-main img { position:absolute; inset:0; width:100%; height:100%; object-fit:cover; object-position:center; opacity:.84; }
.cc-solution-main::after { position:absolute; inset:35% 0 0; background:linear-gradient(0deg,rgba(18,24,20,.95),transparent); content:''; }
.cc-solution-copy { position:absolute; z-index:1; right:28px; bottom:25px; left:28px; }
.cc-solution-copy .cc-kicker { margin-bottom:8px; color:var(--lime); }
.cc-solution-copy h3 { max-width:18ch; margin:0; font-size:clamp(22px,3vw,32px); font-weight:700; letter-spacing:-.045em; }
.cc-solution-copy p { max-width:48ch; margin:8px 0 16px; color:rgba(255,255,255,.75); font-size:12px; font-weight:300; }
.cc-solution-copy .cc-text-link { color:white; }
.cc-side-solutions { display:grid; grid-template-rows:1fr 1fr; gap:16px; }
.cc-solution-tile { display:flex; min-height:182px; flex-direction:column; align-items:flex-start; justify-content:space-between; padding:24px; border-radius:26px; background:var(--lime); color:var(--ink); text-decoration:none; transition:transform .18s ease; }
.cc-solution-tile:hover { transform:translateY(-3px); }
.cc-solution-tile-light { border:1px solid var(--line); background:#f8f8f8; }
.cc-solution-tile .cc-kicker { margin-bottom:12px; color:rgba(33,33,33,.65); }
.cc-solution-tile h3 { margin:0; font-size:22px; font-weight:700; letter-spacing:-.045em; line-height:1.12; }
.cc-solution-tile p { margin:8px 0 0; color:var(--soft); font-size:12px; font-weight:300; line-height:1.6; }
.cc-solution-tile .cc-text-link { margin-top:16px; }
.cc-footer { padding:26px 0; border-top:1px solid var(--line); color:var(--muted); font-size:11px; }
.cc-footer-inner { display:flex; align-items:center; justify-content:space-between; gap:20px; }
.cc-footer .cc-logo { font-size:22px; }
.carbi-canvas a:focus-visible, .carbi-canvas button:focus-visible { outline:3px solid #16855c; outline-offset:3px; }
@media (max-width:900px) {
  .cc-wrap { width:min(100% - 44px,720px); }
  .cc-links { gap:18px; }
  .cc-links a { font-size:12px; }
  .cc-hero-grid { grid-template-columns:minmax(0,1.12fr) minmax(280px,.88fr); gap:30px; }
  .cc-hero h1 { font-size:clamp(42px,5.6vw,58px); }
  .cc-plate { grid-template-columns:minmax(0,1fr) minmax(300px,.95fr); gap:22px; padding:26px; }
  .cc-search-card { padding:16px; }
}
@media (max-width:680px) {
  .cc-wrap { width:calc(100% - 40px); }
  .cc-nav { min-height:68px; gap:14px; }
  .cc-logo { font-size:25px; }
  .cc-links { display:none; position:absolute; top:68px; right:0; left:0; flex-direction:column; align-items:stretch; gap:0; padding:8px 20px 16px; border-bottom:1px solid var(--line); background:white; box-shadow:0 14px 22px rgba(0,0,0,.05); }
  .cc-links-open { display:flex; }
  .cc-links a { padding:13px 4px; border-bottom:1px solid var(--line); font-size:14px; }
  .cc-nav-actions { gap:10px; }
  .cc-login { display:none; }
  .cc-post { min-height:40px; padding:0 14px; font-size:12px; }
  .cc-menu-toggle { display:inline-flex; }
  .cc-hero { padding:52px 0 36px; }
  .cc-hero-grid { grid-template-columns:1fr; gap:28px; }
  .cc-kicker { margin-bottom:13px; font-size:10px; }
  .cc-hero h1 { max-width:12ch; font-size:clamp(42px,11vw,58px); line-height:1.08; }
  .cc-hero h1 span { display:inline; }
  .cc-hero h1 span:not(:last-child)::after { content:' '; }
  .cc-lead { margin:17px 0 22px; font-size:14px; line-height:1.65; }
  .cc-hero-actions { gap:9px; }
  .cc-button { min-height:46px; padding:0 16px; font-size:12px; }
  .cc-proof { margin-top:22px; font-size:11px; }
  .cc-hero-photo { height:300px; border-radius:22px; }
  .cc-photo-caption { display:none; }
  .cc-highlights { padding:12px 0 46px; }
  .cc-highlight-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
  .cc-highlight { padding:17px 10px 17px 0; }
  .cc-highlight:nth-child(3) { padding-left:0; border-left:0; border-top:1px solid var(--line); }
  .cc-highlight:nth-child(4) { border-top:1px solid var(--line); }
  .cc-highlight + .cc-highlight { padding-left:14px; }
  .cc-highlight:nth-child(3) { padding-left:0; }
  .cc-highlight strong { font-size:23px; }
  .cc-highlight span { font-size:10px; }
  .cc-plate { grid-template-columns:1fr; gap:20px; padding:20px; border-radius:24px; }
  .cc-plate-photo { grid-row:1; height:260px; min-height:0; border-radius:18px; }
  .cc-plate-left { grid-row:2; }
  .cc-plate h2 { max-width:16ch; font-size:32px; }
  .cc-plate-copy { padding:4px 2px 0; }
  .cc-plate-copy p { margin:12px 0 14px; font-size:12px; }
  .cc-search-card { padding:14px; border-radius:17px; }
  .cc-input-row { flex-direction:column; }
  .cc-search-submit { min-height:48px; }
  .cc-showcase { padding:60px 0 64px; }
  .cc-listings { padding:60px 0 64px; }
  .cc-listing-grid { grid-template-columns:1fr; gap:14px; }
  .cc-listing-card img { height:230px; }
  .cc-section-head { align-items:flex-start; flex-direction:column; margin-bottom:20px; }
  .cc-section-head h2 { font-size:30px; }
  .cc-solution-grid { grid-template-columns:1fr; gap:12px; }
  .cc-solution-main { min-height:310px; }
  .cc-solution-copy { right:20px; bottom:20px; left:20px; }
  .cc-side-solutions { grid-template-columns:1fr 1fr; grid-template-rows:auto; gap:12px; }
  .cc-solution-tile { min-height:190px; padding:17px; border-radius:20px; }
  .cc-solution-tile h3 { font-size:18px; }
  .cc-solution-tile p { font-size:11px; }
  .cc-text-link { font-size:12px; }
  .cc-footer-inner { align-items:flex-start; flex-direction:column; }
}
@media (prefers-reduced-motion:reduce) {
  .carbi-canvas *, .carbi-canvas *::before, .carbi-canvas *::after { scroll-behavior:auto!important; transition-duration:.01ms!important; animation-duration:.01ms!important; }
}
`;
export const CarbiHomepage = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [plate, setPlate] = useState('');
  const [lookupError, setLookupError] = useState('');
  const [showDemo, setShowDemo] = useState(false);
  function handleLookup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (plate.length !== 7) {
      setLookupError('Digite uma placa com 7 caracteres.');
      setShowDemo(false);
      return;
    }
    setLookupError('');
    setShowDemo(true);
  }
  function updatePlate(value: string) {
    setPlate(value.replace(/[^a-z0-9]/gi, '').toUpperCase().slice(0, 7));
    setLookupError('');
    setShowDemo(false);
  }
  return <main className="carbi-canvas">
      <style>{styles}</style>
      <header className="cc-header">
        <div className="cc-wrap cc-nav">
          <a className="cc-logo" href="#inicio" aria-label="Carbi, início">carbi<span>.</span></a>
          <nav className={`cc-links ${menuOpen ? 'cc-links-open' : ''}`} aria-label="Navegação principal">
            <a href="#comprar" onClick={() => setMenuOpen(false)}>Comprar</a>
            <a href="#caminhoes" onClick={() => setMenuOpen(false)}>Caminhões</a>
            <a href="#anunciar" onClick={() => setMenuOpen(false)}>Vender</a>
            <a href="#marcas" onClick={() => setMenuOpen(false)}>Marcas</a>
            <a href="#qual-carro" onClick={() => setMenuOpen(false)}>Qual carro?</a>
            <a href="#fipe" onClick={() => setMenuOpen(false)}>FIPE</a>
          </nav>
          <div className="cc-nav-actions">
            <a className="cc-login" href="#entrar">Entrar</a>
            <a className="cc-post" href="#anunciar">Anunciar</a>
            <button className="cc-menu-toggle" type="button" aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d={menuOpen ? 'M6 6l12 12M18 6 6 18' : 'M4 7h16M4 12h16M4 17h16'} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
            </button>
          </div>
        </div>
      </header>

      <section className="cc-hero" id="inicio">
        <div className="cc-wrap cc-hero-grid">
          <div className="cc-hero-copy">
            <h1><span>Encontre o carro</span><span><u>certo</u>, sem</span><span>complicação.</span></h1>
            <p className="cc-lead">Anuncie grátis, compare com a FIPE e negocie direto com o vendedor. Dados reais, chat interno e as melhores ofertas de seminovos do país.</p>
            <div className="cc-hero-actions">
              <a className="cc-button cc-button-lime" href="#comprar">Ver estoque completo <Arrow /></a>
              <a className="cc-button cc-button-forest" href="#anunciar"><span aria-hidden="true">＋</span> Anunciar grátis</a>
            </div>
            <div className="cc-proof">
              <span className="cc-proof-dots" aria-hidden="true"><i /><i /><i /></span>
              <span><strong>32 mil+</strong> compradores ativos todo mês</span>
            </div>
          </div>
          <div className="cc-hero-visual">
            <img className="cc-hero-photo" src={heroPhoto} alt="Porsche esportivo em movimento" />
          </div>
        </div>
      </section>

      <section className="cc-highlights" aria-label="Benefícios Carbi">
        <div className="cc-wrap cc-highlight-grid">
          <div className="cc-highlight"><strong>0+</strong><span>Anúncios ativos</span></div>
          <div className="cc-highlight"><strong>0+</strong><span>Visualizações mensais</span></div>
          <div className="cc-highlight"><strong>0+</strong><span>Cidades atendidas</span></div>
          <div className="cc-highlight"><strong>4.9 <span aria-label="estrelas">★</span></strong><span>Avaliação média</span></div>
        </div>
      </section>

      <section className="cc-wrap" id="anunciar">
        <div className="cc-plate" id="fipe">
          <div className="cc-plate-left">
            <div className="cc-plate-copy">
              <span className="cc-kicker">Grátis por tempo limitado</span>
              <h2>Anuncie seu carro em menos de 2 minutos.</h2>
              <p>Consulte pela placa e nós buscamos marca, modelo, ano e FIPE para você.</p>
              <div className="cc-private"><CheckIcon /> A placa não será publicada</div>
            </div>
            <form className="cc-search-card" onSubmit={handleLookup}>
              <label htmlFor="cc-plate">Placa do veículo</label>
              <div className="cc-input-row">
                <div className="cc-input-wrap">
                  <SearchIcon />
                  <input id="cc-plate" aria-label="Placa do veículo" placeholder="ABC1D23" value={plate} maxLength={7} onChange={event => updatePlate(event.target.value)} />
                </div>
                <button className="cc-search-submit" type="submit">Consultar</button>
              </div>
              <p className="cc-form-note" role="status">{lookupError || (showDemo ? 'Prévia demonstrativa: a consulta real será conectada depois.' : 'Digite sua placa para preencher os dados do veículo.')}</p>
              {showDemo && <div className="cc-demo-result" aria-live="polite"><small>Prévia ilustrativa · não é uma consulta real</small><strong>Veículo identificado</strong><span>Marca, modelo e FIPE aparecerão aqui quando a integração for conectada.</span></div>}
            </form>
          </div>
          <img className="cc-plate-photo" src={platePhoto} alt="Picape em uma estrada no deserto" />
        </div>
      </section>

      <section className="cc-wrap cc-listings" id="comprar">
        <div className="cc-section-head">
          <div><h2>Os anúncios mais procurados desta semana</h2></div>
          <a className="cc-text-link" href="#comprar">Ver todos os carros <Arrow /></a>
        </div>
        <div className="cc-listing-grid">
          {[{
          name: 'FIAT BRAVO ESSENCE 1.8 2013',
          trim: '1.8',
          year: '2013',
          mileage: '175k km',
          price: 'R$ 28.900',
          deal: '12% abaixo da FIPE',
          place: 'Santa Luzia, MG'
        }, {
          name: 'JEEP RENEGADE S 2022',
          trim: 'T270 4X4',
          year: '2022',
          mileage: '65k km',
          price: 'R$ 114.900',
          deal: '7% acima da FIPE',
          place: 'Santos, SP'
        }, {
          name: 'CAOA CHERY TIGGO 7 PRO PHEV 2027',
          trim: 'SUPER HYBRID',
          year: '2027',
          mileage: '0 km',
          price: 'R$ 213.900',
          deal: '13% acima da FIPE',
          place: 'Santos, SP'
        }].map((car, index) => <a className="cc-listing-card" href="#comprar" key={car.name}>
            <img src={listingPhotos[index]} alt={car.name} />
            <div className="cc-listing-copy"><small>{car.name.split(' ').slice(0, 2).join(' ')}</small><h3>{car.name}</h3><div className="cc-listing-specs"><span>{car.trim}</span><span>ANO {car.year}</span><span>{car.mileage}</span></div><div className="cc-listing-price"><strong>{car.price}</strong><span>{car.deal}</span></div><div className="cc-listing-specs">{car.place}</div></div>
          </a>)}
        </div>
      </section>

      <footer className="cc-footer"><div className="cc-wrap cc-footer-inner"><a className="cc-logo" href="#inicio">carbi<span>.</span></a><span>Um jeito mais simples de encontrar ou anunciar seu próximo carro.</span><span>© 2026 Carbi</span></div></footer>
    </main>;
};