import { Theme } from './settings/types';
import { CarbiHomepage } from './components/generated/CarbiHomepage';

let theme: Theme = 'light';

function App() {
  function setTheme(theme: Theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setTheme(theme);

  return (
    <>
      <CarbiHomepage />
    </>
  ); // %EXPORT_STATEMENT%
}

export default App;
